package com.capstone.rahul.exity10.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import com.capstone.rahul.exity10.IB1Fragment;
import com.capstone.rahul.exity10.IB2Fragment;
import com.capstone.rahul.exity10.IB3Fragment;
import com.capstone.rahul.exity10.IB4Fragment;
import com.capstone.rahul.exity10.IB5Fragment;
import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.activities.QuestionArray;

public class PeaceFragment extends Fragment {

    ImageButton ib1, ib2, ib3, ib4, ib5;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_peace, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ib1 = (ImageButton) view.findViewById(R.id.ib1);
        ib2 = (ImageButton) view.findViewById(R.id.ib2);
        ib3 = (ImageButton) view.findViewById(R.id.ib3);
        ib4 = (ImageButton) view.findViewById(R.id.ib4);
        ib5 = (ImageButton) view.findViewById(R.id.ib5);

        ib1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getActivity().getSupportFragmentManager();
                Fragment fragment = new IB1Fragment();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, fragment)
                        .addToBackStack("ib1")
                        .commit();

//                Intent intent=new Intent(getActivity(),QuestionArray.class);
//                startActivity(intent);
            }
        });

        ib2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ib2's func
                FragmentManager fm = getActivity().getSupportFragmentManager();
                Fragment fragment = new IB2Fragment();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, fragment)
                        .addToBackStack("ib2")
                        .commit();
            }
        });

        ib3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ib3's func

                FragmentManager fm = getActivity().getSupportFragmentManager();
                Fragment fragment = new IB3Fragment();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, fragment)
                        .addToBackStack("ib3")
                        .commit();
            }
        });

        ib4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ib4's func

                FragmentManager fm = getActivity().getSupportFragmentManager();
                Fragment fragment = new IB4Fragment();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, fragment)
                        .addToBackStack("ib4")
                        .commit();
            }
        });

        ib5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ib5's func
                FragmentManager fm = getActivity().getSupportFragmentManager();
                Fragment fragment = new IB5Fragment();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_container, fragment)
                        .addToBackStack("ib5")
                        .commit();
            }
        });
    }
}
