package com.capstone.rahul.exity10.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.capstone.rahul.exity10.R;

public class QuestionArray extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_array);
    }
}
