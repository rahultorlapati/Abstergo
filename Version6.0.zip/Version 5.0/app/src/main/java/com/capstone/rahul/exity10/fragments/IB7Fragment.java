package com.capstone.rahul.exity10.fragments;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.activities.PeaceResultActivity;

import java.util.ArrayList;
import java.util.List;


public class IB7Fragment extends Fragment {

    private int moodID=7;
    private static View view;
    private static List<TextView> tvques;
    private static List<RatingBar> rques;
    private static List<TextView> tvtrans;
    private static List<String> ques;
    private static List<Integer> rate;
    private static Button bsubmit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ib7, container, false);

        return view;
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        init();

        addListeners();
    }

    private void addListeners() {
        for(int i=0; i<10; i++) {
            final int j = i;
            rques.get(i).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                    rate.set(j, (int) rating);
                    fadeStart(tvtrans.get(j), rating);
                }
            });
        }

        bsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sum = 0;
                for(int i : rate) { sum+=i; }
                Intent result=new Intent(getContext(),PeaceResultActivity.class);
                result.putExtra("moods",moodID);
                result.putExtra("score",sum);
                startActivity(result);
                Toast.makeText(view.getContext(), "Sum is :"+sum, Toast.LENGTH_SHORT).show();
                //    Fragment fragment = ;
            }
        });
    }

    private void fadeStart(TextView tv, float rate) {
        if(rate == 1f) { tv.setTextColor(Color.parseColor("#ff0000")); tv.setText("NOT AT ALL"); }
        if(rate == 2f) { tv.setTextColor(Color.parseColor("#e50000")); tv.setText("SEVERAL DAYS"); }
        if(rate == 3f) { tv.setTextColor(Color.parseColor("#990000")); tv.setText("MORE THAN HALF THE DAYS"); }
        if(rate == 4f) { tv.setTextColor(Color.parseColor("#4c0000")); tv.setText("NEARLY EVERY OTHER DAY"); }
        if(rate == 5f) { tv.setTextColor(Color.parseColor("#190000")); tv.setText("EVERYDAY"); }

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeIn.setFillAfter(true);
        fadeOut.setFillAfter(true);
        fadeIn.setDuration(300);
        fadeOut.setDuration(300);
        fadeOut.setStartOffset(600+fadeIn.getStartOffset());

        tv.setVisibility(View.VISIBLE);
        tv.startAnimation(fadeIn);
        tv.startAnimation(fadeOut);
        tv.setVisibility(View.INVISIBLE);
    }
//DEPRESSION
    private void init() {
        ques = new ArrayList<>();ques.add(">> In a Depressed Mood?");
        ques.add(">> Do you have any feelings of Guilt?");
        ques.add(">> Feeling Suicidal?");
        ques.add(">> Experincing Insomonia?");
        ques.add(">> Felling Agitated?");
        ques.add(">> Any feelings of slowness of thought and speech, impaired ability to concentrate, decreased motor activit?");
        ques.add(">> Any Loss of weight?");
        ques.add(">> Any Symptoms such as loss of libido, menstrual disturbances?");
        ques.add(">> Any Anxiety regarding your health?");
        ques.add(">> Feeling Fatigued, weakness or incapacity to do things?");

        List<TextView> ids = new ArrayList<>();
        List<RatingBar> rids = new ArrayList<>();
        List<TextView> tids = new ArrayList<>();

        ids.add((TextView) view.findViewById(R.id.ib1_tvques1));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques2));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques3));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques4));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques5));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques6));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques7));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques8));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques9));
        ids.add((TextView) view.findViewById(R.id.ib1_tvques10));

        rids.add((RatingBar) view.findViewById(R.id.ib1_rques1));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques2));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques3));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques4));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques5));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques6));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques7));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques8));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques9));
        rids.add((RatingBar) view.findViewById(R.id.ib1_rques10));

        tids.add((TextView) view.findViewById(R.id.ib1_trans1));
        tids.add((TextView) view.findViewById(R.id.ib1_trans2));
        tids.add((TextView) view.findViewById(R.id.ib1_trans3));
        tids.add((TextView) view.findViewById(R.id.ib1_trans4));
        tids.add((TextView) view.findViewById(R.id.ib1_trans5));
        tids.add((TextView) view.findViewById(R.id.ib1_trans6));
        tids.add((TextView) view.findViewById(R.id.ib1_trans7));
        tids.add((TextView) view.findViewById(R.id.ib1_trans8));
        tids.add((TextView) view.findViewById(R.id.ib1_trans9));
        tids.add((TextView) view.findViewById(R.id.ib1_trans10));

       bsubmit = (Button) view.findViewById(R.id.ib1_bsubmit);

        tvques = new ArrayList<TextView>();
        rques = new ArrayList<RatingBar>();
        tvtrans = new ArrayList<>();
        rate = new ArrayList<>();

        for(int i=0; i<10; i++) {
            tvques.add( ids.get(i) );
            rques.add( rids.get(i) );
            tvtrans.add( tids.get(i) );
            tvques.get(i).setText(ques.get(i));
            rate.add(0);
        }
    }
}
