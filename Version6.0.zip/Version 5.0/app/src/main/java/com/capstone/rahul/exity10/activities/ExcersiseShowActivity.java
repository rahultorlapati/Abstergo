package com.capstone.rahul.exity10.activities;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;

public class ExcersiseShowActivity extends AppCompatActivity {

    private static final String TAG = "ExcersiseShowActivity";
    private ImageView imageView;
    private TextView EngAsana;
    private TextView SanskritAsana;
    private TextView Description;
    public int res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excersise_show);

        EngAsana=findViewById(R.id.englishAsana);
        SanskritAsana=findViewById(R.id.SanskritAsana);
        Description=findViewById(R.id.asanadescription);


        imageView= findViewById(R.id.imageView2);
        getIcomingIntent();
    }
    private void getIcomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
        if (getIntent().hasExtra("img name")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");

            res = extras.getInt("img name");
            setValues(res);
        }
    }

    private void setValues(int res) {
        imageView.setImageResource(res);

        switch(res){
            case(R.drawable.running):
                EngAsana.setText(getString(R.string.runningheading));
                SanskritAsana.setText(getString(R.string.runningtype));
                Description.setText(getString(R.string.runningtext));
                break;
            case(R.drawable.elipticalmachine):
                EngAsana.setText(getString(R.string.ellipticalheading));
                SanskritAsana.setText(getString(R.string.ellipticaltype));
                Description.setText(getString(R.string.ellipticaltext));
                break;
            case(R.drawable.chestbrenchpress):
                EngAsana.setText(getString(R.string.benchpressheading));
                SanskritAsana.setText(getString(R.string.benchpresstype));
                Description.setText(getString(R.string.benchprsstext));
                break;
            case(R.drawable.chestcablecrossover):
                EngAsana.setText(getString(R.string.cablecrossoverheading));
                SanskritAsana.setText(getString(R.string.cablecrossovertype));
                Description.setText(getString(R.string.cablecrossovertext));
                break;
            case(R.drawable.bicepcurl):
                EngAsana.setText(getString(R.string.bicepcurlheading));
                SanskritAsana.setText(getString(R.string.bicepcurltype));
                Description.setText(getString(R.string.bicepcurltext));
                break;
            case(R.drawable.dumbbellcurl):
                EngAsana.setText(getString(R.string.dumbbellcurlheading));
                SanskritAsana.setText(getString(R.string.dumbbellcurltype));
                Description.setText(getString(R.string.dumbbellcurltext));
                break;
            case(R.drawable.boundanglepose):
                EngAsana.setText(getString(R.string.asana_one_eng));
                SanskritAsana.setText(getString(R.string.asana_one_san));
                Description.setText(getString(R.string.asana_one_text));
                break;
            case(R.drawable.bowpose):
                EngAsana.setText(getString(R.string.asana_two_eng));
                SanskritAsana.setText(getString(R.string.asana_two_san));
                Description.setText(getString(R.string.asana_two_text));
                break;
            case(R.drawable.bridgepose):
                EngAsana.setText(getString(R.string.asana_three_eng));
                SanskritAsana.setText(getString(R.string.asana_three_san));
                Description.setText(getString(R.string.asana_three_text));
                break;
            case(R.drawable.cobrapose):
                EngAsana.setText(getString(R.string.asana_four_eng));
                SanskritAsana.setText(getString(R.string.asana_four_san));
                Description.setText(getString(R.string.asana_four_text));
                break;
            case(R.drawable.fishpose):
                EngAsana.setText(getString(R.string.asana_nine_eng));
                SanskritAsana.setText(getString(R.string.asana_nine_san));
                Description.setText(getString(R.string.asana_nine_text));
                break;
            case(R.drawable.monkeypose):
                EngAsana.setText(getString(R.string.asana_ten_eng));
                SanskritAsana.setText(getString(R.string.asana_ten_san));
                Description.setText(getString(R.string.asana_ten_text));
                break;
            default:

        }

    }
}
