package com.capstone.rahul.exity10.activities;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;
import com.elmargomez.typer.Font;
import com.elmargomez.typer.Typer;

public class DietShowActivity extends AppCompatActivity {

    private static final String TAG = "DietShowActivity";
    String imageName;
    TextView content;

    CollapsingToolbarLayout collapse;
    AppBarLayout appBarLayout;
    Typeface font;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_diet);

        View view=findViewById(R.id.insde_diet_show);
        content=view.findViewById(R.id.content);
        collapse=findViewById(R.id.collapsingtoolbar_layout);
        appBarLayout =  findViewById(R.id.app_bar);
         font = Typer.set(getApplicationContext()).getFont(Font.ROBOTO_MEDIUM);

        Toolbar toolbar =  findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
       // getSupportActionBar().setDisplayShowTitleEnabled(false);      To hide the title in toolbar
        Log.d(TAG, "onCreate: started");
        getIcomingIntent();
    }

    private void getIcomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
            if (getIntent().hasExtra("diet url") && getIntent().hasExtra("diet name")) {
                Log.d(TAG, "getIcomingIntent: Found Extras");

                int res = extras.getInt("diet url");
                imageName = getIntent().getStringExtra("diet name");

                setImage(res,imageName);
                showTitleOnCollapse();
            }
        }
    
    private void setImage(int res,String imageName){
        Log.d(TAG, "setImage: setting image and diet plan");
        collapse.setBackgroundResource(res);

        switch (imageName){
            case "Paleo":
                content.setText(getString(R.string.diet_paleo));
                break;
            case "Vegan":
                content.setText(getString(R.string.diet_vegan));
                break;
            case "Low-Carb":
                content.setText(getString(R.string.diet_lowcarb));
                break;
            case "Dukan":
                content.setText(getString(R.string.diet_dukan));
                break;
            case "Ultra Low-Fat":
                content.setText(getString(R.string.diet_ultra_low));
                break;
            case "Atkins":
                content.setText(getString(R.string.diet_atkins));
                break;
            case "Zone":
                content.setText(getString(R.string.diet_zone));
                break;
            case "Intermittent Fasting":
                content.setText(getString(R.string.diet_fasting));
                break;

            case "Muscle Builder":
                content.setText(getString(R.string.diet_indian_muscle_gain));
                break;
            case "Ideal Diet":
                content.setText(getString(R.string.diet_indian_ideal));
                break;
            case "Keto":
                content.setText(getString(R.string.diet_indian_keto));
                break;
            case "Diabetic":
                content.setText(getString(R.string.diet_indian_diabetic));
                break;
            case "Weight Loss":
                content.setText(getString(R.string.diet_indian_weight_loss));
                break;
                default:

        }
    }

    public void showTitleOnCollapse(){
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = true;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffset == 0) {
                    collapse.setTitle(imageName);
                    isShow = true;
                } else if(isShow) {
                    collapse.setTitle(" ");
                    collapse.setExpandedTitleTypeface(font);
                    isShow = false;
                }
            }
        });
    }

}
