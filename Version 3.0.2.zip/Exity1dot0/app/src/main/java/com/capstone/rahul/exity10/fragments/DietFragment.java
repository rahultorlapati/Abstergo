package com.capstone.rahul.exity10.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.capstone.rahul.exity10.model.DietPlanModel;
import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.activities.DietShowActivity;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link DietFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link DietFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DietFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public DietFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment DietFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DietFragment newInstance(String param1, String param2) {
        DietFragment fragment = new DietFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    private ArrayList<DietPlanModel>dietplansList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_diet, container, false);

        dietplansList=new ArrayList<>();

        dietplansList.add(
                new DietPlanModel(
                        "Paleo",
                        "Ideal if you live an active lifestyle and want to gain muscle.",
                        R.drawable.paleo));

        dietplansList.add(
                new DietPlanModel(
                        "Vegan",
                        "Ideal if you want to abstain from the use of animal products",
                        R.drawable.vegan));
        dietplansList.add(
                new DietPlanModel(
                        "Low-Carb",
                        "Ideal if want to make a healthy change in your eating habits.",
                        R.drawable.lowcarb));
        dietplansList.add(
                new DietPlanModel(
                        "Dukan",
                        "Ideal if want to make a healthy change in your eating habits.",
                        R.drawable.dukan));
        dietplansList.add(
                new DietPlanModel(
                        "Ultra Low-Fat",
                        "Ideal if you want to turn your body into a fat-burning machine.",
                        R.drawable.ultralowfat));
        dietplansList.add(
                new DietPlanModel(
                        "Atkins",
                        "Ideal for people suffering from diabetes",
                        R.drawable.atkins));
        dietplansList.add(
                new DietPlanModel(
                        "Zone",
                        "Ideal if want to make a healthy change in your eating habits.",
                        R.drawable.zone));
        dietplansList.add(
                new DietPlanModel(
                        "Intermittent Fasting",
                        "Ideal if want to make a healthy change in your eating habits.",
                        R.drawable.fasting));
        RecyclerView recyclerView= view.findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(new RecyclerViewAdapter(getActivity(),dietplansList));

        return view;
    }


    public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {
    List<DietPlanModel> dietList;
    Context mCtx;

    RecyclerViewAdapter(Context mCtx,List<DietPlanModel> dietList) {
        this.mCtx=mCtx;
        this.dietList = dietList;
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.diet_cardview, parent, false);
        RecyclerViewHolder rvh = new RecyclerViewHolder(v);
        return rvh;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, final int position) {
        holder.imageView.setImageResource(dietList.get(position).getImage());

        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Log.d(TAG, "onClick: clicked on:" + dietList.get(position).getTitle());

               // Toast.makeText(mCtx, dietList.get(position).getTitle(), Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(mCtx,DietShowActivity.class);
               intent.putExtra("diet name",dietList.get(position).getTitle());
                intent.putExtra("diet url",dietList.get(position).getImage());
                mCtx.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dietList.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        CardView mCardView;
        ImageView imageView;
        RelativeLayout relativeLayout;

        RecyclerViewHolder(View itemView) {
            super(itemView);

            mCardView = itemView.findViewById(R.id.card_container);
            imageView = itemView.findViewById(R.id.imageView);
            relativeLayout=itemView.findViewById(R.id.card_parent);
            }
        }

    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            //Toast.makeText(context, "Fragment Attached", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
