package com.capstone.rahul.exity10.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;

/**
 * Created by Sagar on 08-04-2018.
 */

public class UsersActivity extends AppCompatActivity {

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        textView=findViewById(R.id.texttt);
        String nameFromIntent=getIntent().getStringExtra("EMAIL");
        textView.setText("Welcome " + nameFromIntent);
}
}
