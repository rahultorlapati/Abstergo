package com.capstone.rahul.exity10.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;

public class DietShowActivity extends AppCompatActivity {
    private static final String TAG = "DietShowActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_diet);
        Toolbar toolbar =  findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Log.d(TAG, "onCreate: started");

        getIcomingIntent();
    }

    private void getIcomingIntent() {
        Log.d(TAG, "getIcomingIntent: checking for incoming intent");

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
            if (getIntent().hasExtra("diet name") && getIntent().hasExtra("diet url")) {
                Log.d(TAG, "getIcomingIntent: Found Extras");

                int res = extras.getInt("diet url");
                String imageName = getIntent().getStringExtra("diet name");

                setImage(res, imageName);
            }
        }
    
    private void setImage(int res,String imageName){
        Log.d(TAG, "setImage: setting image and diet plan");

      //  TextView name=findViewById(R.id.image_description);
        CollapsingToolbarLayout collapse=findViewById(R.id.collapsingtoolbar_layout);
//        ImageView img=findViewById(R.id.imagenew);
        //name.setText(imageName);
        collapse.setBackgroundResource(res);
        collapse.setTitle(imageName);
        //      img.setImageResource(res);
    }
}
