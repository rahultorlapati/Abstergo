package com.capstone.rahul.exity10.activities;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;

public class ExcersiseShowActivity extends AppCompatActivity {

    private static final String TAG = "ExcersiseShowActivity";
    String imageName;
    ImageView imageView;
    //int res;
    //TextView content;

   // CollapsingToolbarLayout collapse;
   // AppBarLayout appBarLayout;
    //Typeface font;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excersise_show);
        imageView= findViewById(R.id.imageView2);
        getIcomingIntent();
    }
    private void getIcomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
        if (getIntent().hasExtra("img name")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");

            int res = extras.getInt("img name");
           // imageName = getIntent().getStringExtra("img name");

            setImage(res);
            //showTitleOnCollapse();
        }
    }

    private void setImage(int res) {


        //String uri = "@drawable/myresource";  // where myresource (without the extension) is the file

        //int imageResource = getResources().getIdentifier(uri, null, getPackageName());


       // Drawable res = getResources().getDrawable(imageResource);
        imageView.setImageResource(res);
    }
}
