package com.capstone.rahul.exity10.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Spinner;

import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.activities.ExcersiseShowActivity;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ExcerciseFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ExcerciseFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ExcerciseFragment extends Fragment{// implements AdapterView.OnItemSelectedListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private Intent mCtx;

    public ExcerciseFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ExcerciseFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ExcerciseFragment newInstance(String param1, String param2) {
        ExcerciseFragment fragment = new ExcerciseFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    List<Integer> imageResList = new ArrayList<Integer>();
    List<Integer> imageYogaList = new ArrayList<Integer>();
    String [] values ={"Workout","Yoga"};
    Spinner spin;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_excercise, container, false);

           /* Spinner spinner = v.findViewById(R.id.spinner1);
            ArrayAdapter LTRadapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, values);
            LTRadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(LTRadapter);*/
        final RecyclerView recyclerView = v.findViewById(R.id.recycler_view);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        gridLayoutManager.setSpanSizeLookup(new CustomSpanSizeLookup());
        recyclerView.setLayoutManager(gridLayoutManager);






        spin = (Spinner) v.findViewById(R.id.spinner1);
        String[] objects ={"Workout","Yoga"};
        ArrayAdapter adapter = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1 ,objects);
        spin.setAdapter(adapter);
        //spin.setOnItemSelectedListener(getActivity());
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(AdapterView<?> parent, View view,int position, long id)
            {
                if (parent.getItemAtPosition(position).toString().equals("Workout"))
                {
                    List<Integer> imageResList = getMockedImageList();

                    // specify that grid will consist of 2 columns

                    // this is fake list of images
                    recyclerView.setAdapter(new Adapter(getActivity(),imageResList));
                }


                if (parent.getItemAtPosition(position).toString().equals("Yoga"))
                {
                    List<Integer> imageYogaList = getMockedImageList2();
                    // //RecyclerView recyclerView = v.findViewById(R.id.recycler_view);
                    // specify that grid will consist of 2 columns
                    GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
                    gridLayoutManager.setSpanSizeLookup(new CustomSpanSizeLookup());

                    recyclerView.setLayoutManager(gridLayoutManager);
                    // this is fake list of images

                    recyclerView.setAdapter(new Adapter(getActivity(),imageYogaList));

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {


            }
        });
        return v;
    }

    /*
    @Override
    public void onItemSelected(AdapterView<?> arg0,View arg1,int position,long id){
        Toast.makeText(getContext(), values[position], Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    */

    private static class CustomSpanSizeLookup extends GridLayoutManager.SpanSizeLookup {
        @Override
        public int getSpanSize(int i) {
            // the rest of the items will behave normally and occupy only 1 span
            return 1;
        }
    }

    private List<Integer> getMockedImageList() {

        imageResList.add(R.drawable.running);
        imageResList.add(R.drawable.elipticalmachine);
        imageResList.add(R.drawable.chestbrenchpress);
        imageResList.add(R.drawable.chestcablecrossover);
        imageResList.add(R.drawable.bicepcurl);
        imageResList.add(R.drawable.dumbbellcurl);
        imageResList.add(R.drawable.forearmwristcurl);
        imageResList.add(R.drawable.forearmcablecurl);
        imageResList.add(R.drawable.bicyclecrunch);
        imageResList.add(R.drawable.mountainclimber);
        imageResList.add(R.drawable.handplank);
        imageResList.add(R.drawable.dumbellcalfraise);
        imageResList.add(R.drawable.latpulldown);
        imageResList.add(R.drawable.dumbbellrow);
        imageResList.add(R.drawable.triceppushdown);
        imageResList.add(R.drawable.triceppress);
        imageResList.add(R.drawable.cablegoodmorning);
        imageResList.add(R.drawable.kettlebell);


        return imageResList;
    }

    private List<Integer> getMockedImageList2()
    {
        imageYogaList.add(R.drawable.boundanglepose);
        imageYogaList.add(R.drawable.bowpose);
        imageYogaList.add(R.drawable.bridgepose);
        imageYogaList.add(R.drawable.cobrapose);
        imageYogaList.add(R.drawable.fishpose);
        imageYogaList.add(R.drawable.monkeypose);
        imageYogaList.add(R.drawable.plough);
        imageYogaList.add(R.drawable.headstand);
        imageYogaList.add(R.drawable.spinaltwist);
        imageYogaList.add(R.drawable.cranepose);
        imageYogaList.add(R.drawable.singlehandwheel);
        imageYogaList.add(R.drawable.wheelpose);
        imageYogaList.add(R.drawable.extendedheadtotoe);
        imageYogaList.add(R.drawable.threeleggeddownwarddog);
        imageYogaList.add(R.drawable.trianglepose);
        imageYogaList.add(R.drawable.scorpion);
        imageYogaList.add(R.drawable.headtoknee);
        imageYogaList.add(R.drawable.seatedforwardbend);

        return imageYogaList;

    }


    public class Adapter extends RecyclerView.Adapter {
        // I assume that you will pass images as list of resources, but this can be easily switched to a list of URLS
        private List<Integer> imageResList = new ArrayList<Integer>();
        Context context;

        public Adapter(Context context,List<Integer> imageUrlList) {
            this.imageResList = imageUrlList;
            this.context=context;
        }


        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.excercise_recycler_item, viewGroup, false);

            return new ItemViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
            ItemViewHolder itemViewHolder = (ItemViewHolder) viewHolder;
            itemViewHolder.item.setImageResource(imageResList.get(i));
            viewHolder.itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    Log.d(TAG, "onClick: clicked on:" + imageResList.get(i));
                    imageResList.get(i);


                    Intent intent=new Intent(context,ExcersiseShowActivity.class);
                    intent.putExtra("img name",imageResList.get(i));
                    context.startActivity(intent);
                }
                class SpinnerActivity extends Activity implements AdapterView.OnItemSelectedListener {
                    public void onItemSelected(AdapterView<?> parent, View view,
                                               int pos, long id) {
                        // An item was selected. You can retrieve the selected item using
                        // parent.getItemAtPosition(pos)
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                        // Another interface callback
                    }

                }
            });
        }

        @Override
        public int getItemCount() {
            return imageResList.size();
        }




        public class ItemViewHolder extends RecyclerView.ViewHolder {
            private ImageView item;
            GridLayout gridLayout;

            @SuppressLint("WrongViewCast")
            public ItemViewHolder(View itemView) {
                super(itemView);

                this.item = itemView.findViewById(R.id.item_image);
                gridLayout=itemView.findViewById(R.id.layout_holder);
            }
        }


    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            // Toast.makeText(context, "Fragment Attached", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
