package com.capstone.rahul.exity10.sql;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Sagar on 12-04-2018.
 */

public class Session {
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    Context context;

    public Session(Context context){
        this.context=context;
        preferences=context.getSharedPreferences("myapp",Context.MODE_PRIVATE);
        editor=preferences.edit();
    }

    public void setLoggedin(boolean logggedin){
        editor.putBoolean("loggedInmode",logggedin);
        editor.commit();
    }

    public boolean loggedin(){
        return preferences.getBoolean("loggedInmode",false);
    }

    public void setemail(String key,String value){
        editor.putString(key, value);
        editor.commit();
    }

    public String getemail(String key){
        return preferences.getString(key, null);
    }

    public void setWater(String key,int value){
        editor.putInt(key,value);
        editor.commit();
    }

    public int getWater(String key){
        return preferences.getInt(key, 0);
    }

    public void setfoodval(String key,float value){
        editor.putFloat(key, value);
        editor.commit();
    }
    public float getfoodval(String key){
        return preferences.getFloat(key, 0.0f);
    }

    public void setbreakfast(String key,String value){
        editor.putString(key, value);
        editor.commit();
    }

    public String getbreakfast(String key){
        return preferences.getString(key, "Add Breakfast");
    }

    public void setlunch(String key,String value){
        editor.putString(key, value);
        editor.commit();
    }

    public String getlunch(String key){
        return preferences.getString(key, "Add Lunch");
    }

    public void setdinner(String key,String value){
        editor.putString(key, value);
        editor.commit();
    }

    public String getdinner(String key){
        return preferences.getString(key, "Add Dinner");
    }

    public void setsnacks(String key,String value){
        editor.putString(key, value);
        editor.commit();
    }

    public String getsnacks(String key){
        return preferences.getString(key, "Add Snacks");
    }




}
