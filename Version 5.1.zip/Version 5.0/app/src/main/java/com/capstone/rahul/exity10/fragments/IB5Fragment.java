package com.capstone.rahul.exity10.fragments;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.capstone.rahul.exity10.R;

import java.util.ArrayList;
import java.util.List;


public class IB5Fragment extends Fragment {

    private static View view;
    private static List<TextView> tvques;
    private static List<RatingBar> rques;
    private static List<TextView> tvtrans;
    private static List<String> ques;
    private static List<Integer> rate;
    private static Button bsubmit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ib5, container, false);

        return view;
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        init();

        addListeners();
    }

    private void addListeners() {
        for(int i=0; i<10; i++) {
            final int j = i;
            rques.get(i).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                    rate.set(j, (int) rating);
                    fadeStart(tvtrans.get(j), rating);
                }
            });
        }

        bsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sum = 0;
                for(int i : rate) { sum+=i; }
                Toast.makeText(view.getContext(), "Sum is :"+sum, Toast.LENGTH_SHORT).show();
                //    Fragment fragment = ;
            }
        });
    }

    private void fadeStart(TextView tv, float rate) {
        if(rate == 1f) { tv.setTextColor(Color.parseColor("#ff0000")); tv.setText("NEVER"); }
        if(rate == 2f) { tv.setTextColor(Color.parseColor("#e50000")); tv.setText("ALMOST NEVER"); }
        if(rate == 3f) { tv.setTextColor(Color.parseColor("#990000")); tv.setText("SOMETIME"); }
        if(rate == 4f) { tv.setTextColor(Color.parseColor("#4c0000")); tv.setText("FAIRLY OFTEN"); }
        if(rate == 5f) { tv.setTextColor(Color.parseColor("#190000")); tv.setText("VERY OFTEN"); }

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeIn.setFillAfter(true);
        fadeOut.setFillAfter(true);
        fadeIn.setDuration(300);
        fadeOut.setDuration(300);
        fadeOut.setStartOffset(600+fadeIn.getStartOffset());

        tv.setVisibility(View.VISIBLE);
        tv.startAnimation(fadeIn);
        tv.startAnimation(fadeOut);
        tv.setVisibility(View.INVISIBLE);
    }

    private void init() {
        ques = new ArrayList<>();
        ques.add(">> Being upset because of something that happend unexpectedly?");
        ques.add(">> Felt nervous and stressed?");
        ques.add(">> Felt that you were unable to control important things in your life?");
        ques.add(">> Felt confident about your ability to hande your personal problems?");
        ques.add(">> Felt that things were going in your way?");
        ques.add(">> Found that you could not cope with all the things you had to do?");
        ques.add(">> Being able to control irritation in your life?");
        ques.add(">> Felt that you were on top of things?");
        ques.add(">> Been angered because of things that happend that were out of your control?");
        ques.add(">> Felt difficulty were piling up so high that you could not overcome them?");

        List<TextView> ids = new ArrayList<>();
        List<RatingBar> rids = new ArrayList<>();
        List<TextView> tids = new ArrayList<>();

        ids.add((TextView) view.findViewById(R.id.ib5_tvques1));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques2));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques3));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques4));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques5));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques6));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques7));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques8));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques9));
        ids.add((TextView) view.findViewById(R.id.ib5_tvques10));

        rids.add((RatingBar) view.findViewById(R.id.ib5_rques1));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques2));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques3));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques4));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques5));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques6));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques7));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques8));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques9));
        rids.add((RatingBar) view.findViewById(R.id.ib5_rques10));

        tids.add((TextView) view.findViewById(R.id.ib5_trans1));
        tids.add((TextView) view.findViewById(R.id.ib5_trans2));
        tids.add((TextView) view.findViewById(R.id.ib5_trans3));
        tids.add((TextView) view.findViewById(R.id.ib5_trans4));
        tids.add((TextView) view.findViewById(R.id.ib5_trans5));
        tids.add((TextView) view.findViewById(R.id.ib5_trans6));
        tids.add((TextView) view.findViewById(R.id.ib5_trans7));
        tids.add((TextView) view.findViewById(R.id.ib5_trans8));
        tids.add((TextView) view.findViewById(R.id.ib5_trans9));
        tids.add((TextView) view.findViewById(R.id.ib5_trans10));

        bsubmit = (Button) view.findViewById(R.id.ib5_bsubmit);

        tvques = new ArrayList<TextView>();
        rques = new ArrayList<RatingBar>();
        tvtrans = new ArrayList<>();
        rate = new ArrayList<>();

        for(int i=0; i<10; i++) {
            tvques.add( ids.get(i) );
            rques.add( rids.get(i) );
            tvtrans.add( tids.get(i) );
            tvques.get(i).setText(ques.get(i));
            rate.add(0);
        }
    }
}
