package com.capstone.rahul.exity10.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.capstone.rahul.exity10.fragments.DietFragment;
import com.capstone.rahul.exity10.fragments.ExcerciseFragment;
import com.capstone.rahul.exity10.fragments.HomeFragment;
import com.capstone.rahul.exity10.fragments.JournalFragment;
import com.capstone.rahul.exity10.fragments.PeaceFragment;
import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.sql.Session;


public class MainActivity extends AppCompatActivity {


    private static final String TAG = "MainActivity";
    // DataFromActivityToFragment dataFromActivityToFragment;
    public Bundle bundle=new Bundle();
    private Session session;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    fragment = new HomeFragment();
                    fragment.setArguments(bundle);
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_routine:
                   fragment = new ExcerciseFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_journal:
                    fragment = new JournalFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_food:
                    fragment = new DietFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_meditate:

                    fragment = new PeaceFragment();
                    loadFragment(fragment);
                    return true;
            }
            return false;
        }
    };

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.setting_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_profile) {
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
        }

        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*String nameFromIntent=getIntent().getStringExtra("EMAIL");
        bundle.putString("messagefromactivity",nameFromIntent);*/

        session=new Session(this);

        if(!session.loggedin()){
            logout();
        }
        getIcomingIntent();

        loadFragment(new HomeFragment());

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }



    private void loadFragment(Fragment fragment){
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void getIcomingIntent() {
        Log.d(TAG, "getIcomingIntent: checking for incoming intent");

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: EXTRASS NOT FOUNDDD");
            return;
        }
        if (getIntent().hasExtra("EMAIL")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");

            String nameFromIntent=getIntent().getStringExtra("EMAIL");
            Toast.makeText(this, "Welcome " +nameFromIntent, Toast.LENGTH_LONG).show();
          // bundle.putString("messagefromactivity",nameFromIntent);
            //String imageName = getIntent().getStringExtra("diet name");
            //setImage(res, imageName);

            session.setemail("email",nameFromIntent);
        }
    }

    private void logout(){
        session.setLoggedin(false);
        finish();
        startActivity(new Intent(MainActivity.this,loginActivity.class));
    }

    /*
    public static void setDefaults(String key, String value, Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.commit();
    }*/

}
