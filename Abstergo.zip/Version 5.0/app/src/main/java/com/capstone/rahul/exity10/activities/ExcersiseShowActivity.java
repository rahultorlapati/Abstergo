package com.capstone.rahul.exity10.activities;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;

public class ExcersiseShowActivity extends AppCompatActivity {

    private static final String TAG = "ExcersiseShowActivity";
    private ImageView imageView;
    private TextView EngAsana;
    private TextView SanskritAsana;
    private TextView Description;
    public int res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excersise_show);

        EngAsana=findViewById(R.id.englishAsana);
        SanskritAsana=findViewById(R.id.SanskritAsana);
        Description=findViewById(R.id.asanadescription);


        imageView= findViewById(R.id.imageView2);
        getIcomingIntent();
    }
    private void getIcomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
        if (getIntent().hasExtra("img name")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");

            res = extras.getInt("img name");
            setValues(res);
        }
    }

    private void setValues(int res) {
        imageView.setImageResource(res);

        switch(res){
            case(R.drawable.running):
                SanskritAsana.setText(getString(R.string.runningheading));
                EngAsana.setText(getString(R.string.workout_cardio));
                Description.setText(getString(R.string.runningtext));
                break;
            case(R.drawable.elipticalmachine):
                SanskritAsana.setText(getString(R.string.ellipticalheading));
                EngAsana.setText(getString(R.string.workout_cardio));
                Description.setText(getString(R.string.ellipticaltext));
                break;
            case(R.drawable.chestbrenchpress):
                SanskritAsana.setText(getString(R.string.benchpressheading));
                EngAsana.setText(getString(R.string.workout_chest));
                Description.setText(getString(R.string.benchprsstext));
                break;
            case(R.drawable.chestcablecrossover):
                SanskritAsana.setText(getString(R.string.cablecrossoverheading));
                EngAsana.setText(getString(R.string.workout_chest));
                Description.setText(getString(R.string.cablecrossovertext));
                break;
            case(R.drawable.bicepcurl):
                SanskritAsana.setText(getString(R.string.bicepcurlheading));
                EngAsana.setText(getString(R.string.workout_bicep));
                Description.setText(getString(R.string.bicepcurltext));
                break;
            case(R.drawable.dumbbellcurl):
                SanskritAsana.setText(getString(R.string.dumbbellcurlheading));
                EngAsana.setText(getString(R.string.workout_bicep));
                Description.setText(getString(R.string.dumbbellcurltext));
                break;
            case(R.drawable.forearmwristcurl):
                SanskritAsana.setText(getString(R.string.workout_one));
                EngAsana.setText(getString(R.string.workout_foraerm));
                Description.setText(getString(R.string.one_text));
                break;
            case(R.drawable.forearmcablecurl):
                SanskritAsana.setText(getString(R.string.workout_two));
                EngAsana.setText(getString(R.string.workout_foraerm));
                Description.setText(getString(R.string.two_text));
                break;
            case(R.drawable.bicyclecrunch):
                SanskritAsana.setText(getString(R.string.workout_three));
                EngAsana.setText(getString(R.string.workout_abs));
                Description.setText(getString(R.string.three_text));
                break;
            case(R.drawable.mountainclimber):
                SanskritAsana.setText(getString(R.string.workout_four));
                EngAsana.setText(getString(R.string.workout_abs));
                Description.setText(getString(R.string.four_text));
                break;
            case(R.drawable.handplank):
                SanskritAsana.setText(getString(R.string.workout_five));
                EngAsana.setText(getString(R.string.workout_abs));
                Description.setText(getString(R.string.five_text));
                break;
            case(R.drawable.dumbellcalfraise):
                SanskritAsana.setText(getString(R.string.workout_six));
                EngAsana.setText(getString(R.string.workout_calves));
                Description.setText(getString(R.string.six_text));
                break;
            case(R.drawable.latpulldown):
                SanskritAsana.setText(getString(R.string.workout_seven));
                EngAsana.setText(getString(R.string.workout_lats));
                Description.setText(getString(R.string.seven_text));
                break;
            case(R.drawable.dumbbellrow):
                SanskritAsana.setText(getString(R.string.workout_eight));
                EngAsana.setText(getString(R.string.workout_lats));
                Description.setText(getString(R.string.eight_text));
                break;
            case(R.drawable.triceppushdown):
                SanskritAsana.setText(getString(R.string.workout_nine));
                EngAsana.setText(getString(R.string.workout_triceps));
                Description.setText(getString(R.string.nine_text));
                break;
            case(R.drawable.triceppress):
                SanskritAsana.setText(getString(R.string.workout_ten));
                EngAsana.setText(getString(R.string.workout_triceps));
                Description.setText(getString(R.string.ten_text));
                break;
            case(R.drawable.cablegoodmorning):
                SanskritAsana.setText(getString(R.string.workout_eleven));
                EngAsana.setText(getString(R.string.workout_back));
                Description.setText(getString(R.string.eleven_text));
                break;
            case(R.drawable.kettlebell):
                SanskritAsana.setText(getString(R.string.workout_twelve));
                EngAsana.setText(getString(R.string.workout_back));
                Description.setText(getString(R.string.twelve_text));
                break;


            case(R.drawable.boundanglepose):
                EngAsana.setText(getString(R.string.asana_one_eng));
                SanskritAsana.setText(getString(R.string.asana_one_san));
                Description.setText(getString(R.string.asana_one_text));
                break;
            case(R.drawable.bowpose):
                EngAsana.setText(getString(R.string.asana_two_eng));
                SanskritAsana.setText(getString(R.string.asana_two_san));
                Description.setText(getString(R.string.asana_two_text));
                break;
            case(R.drawable.bridgepose):
                EngAsana.setText(getString(R.string.asana_three_eng));
                SanskritAsana.setText(getString(R.string.asana_three_san));
                Description.setText(getString(R.string.asana_three_text));
                break;
            case(R.drawable.cobrapose):
                EngAsana.setText(getString(R.string.asana_four_eng));
                SanskritAsana.setText(getString(R.string.asana_four_san));
                Description.setText(getString(R.string.asana_four_text));
                break;
            case(R.drawable.fishpose):
                EngAsana.setText(getString(R.string.asana_nine_eng));
                SanskritAsana.setText(getString(R.string.asana_nine_san));
                Description.setText(getString(R.string.asana_nine_text));
                break;
            case(R.drawable.monkeypose):
                EngAsana.setText(getString(R.string.asana_ten_eng));
                SanskritAsana.setText(getString(R.string.asana_ten_san));
                Description.setText(getString(R.string.asana_ten_text));
                break;
            case(R.drawable.plough):
                EngAsana.setText(getString(R.string.asana_five_eng));
                SanskritAsana.setText(getString(R.string.asana_five_san));
                Description.setText(getString(R.string.asana_five_text));
                break;
            case(R.drawable.headstand):
                EngAsana.setText(getString(R.string.asana_six_eng));
                SanskritAsana.setText(getString(R.string.asana_six_san));
                Description.setText(getString(R.string.asana_six_text));
                break;
            case(R.drawable.spinaltwist):
                EngAsana.setText(getString(R.string.asana_seven_eng));
                SanskritAsana.setText(getString(R.string.asana_seven_san));
                Description.setText(getString(R.string.asana_seven_text));
                break;
            case(R.drawable.cranepose):
                EngAsana.setText(getString(R.string.asana_eight_eng));
                SanskritAsana.setText(getString(R.string.asana_eight_san));
                Description.setText(getString(R.string.asana_one_text));
                break;
            case(R.drawable.singlehandwheel):
                EngAsana.setText(getString(R.string.asana_eleven_eng));
                SanskritAsana.setText(getString(R.string.asana_eleven_san));
                Description.setText(getString(R.string.asana_two_text));
                break;
            case(R.drawable.wheelpose):
                EngAsana.setText(getString(R.string.asana_twelve_eng));
                SanskritAsana.setText(getString(R.string.asana_twelve_san));
                Description.setText(getString(R.string.asana_three_text));
                break;
            case(R.drawable.extendedheadtotoe):
                EngAsana.setText(getString(R.string.asana_thirteen_eng));
                SanskritAsana.setText(getString(R.string.asana_thirteen_san));
                Description.setText(getString(R.string.asana_seven_text));
                break;
            case(R.drawable.threeleggeddownwarddog):
                EngAsana.setText(getString(R.string.asana_fourteen_eng));
                SanskritAsana.setText(getString(R.string.asana_fourteen_san));
                Description.setText(getString(R.string.asana_four_text));
                break;
            case(R.drawable.trianglepose):
                EngAsana.setText(getString(R.string.asana_fifteen_eng));
                SanskritAsana.setText(getString(R.string.asana_fifteen_san));
                Description.setText(getString(R.string.asana_five_text));
                break;
            case(R.drawable.scorpion):
                EngAsana.setText(getString(R.string.asana_sixteen_eng));
                SanskritAsana.setText(getString(R.string.asana_sixteen_san));
                Description.setText(getString(R.string.asana_nine_text));
                break;
            case(R.drawable.headtoknee):
                EngAsana.setText(getString(R.string.asana_seventeen_eng));
                SanskritAsana.setText(getString(R.string.asana_seventeen_san));
                Description.setText(getString(R.string.asana_seven_text));
                break;
            case(R.drawable.seatedforwardbend):
                EngAsana.setText(getString(R.string.asana_eighteen_san));
                SanskritAsana.setText(getString(R.string.asana_eighteen_eng));
                Description.setText(getString(R.string.asana_six_text));
                break;


            default:

        }

    }
}