package com.capstone.rahul.exity10.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.activities.PeaceResultActivity;

import java.util.ArrayList;
import java.util.List;


public class IB3Fragment extends Fragment {

    private int moodID=3;
    private static View view;
    private static List<TextView> tvques;
    private static List<RatingBar> rques;
    private static List<TextView> tvtrans;
    private static List<String> ques;
    private static List<Integer> rate;
    private static Button bsubmit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ib3, container, false);

        return view;
    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        init();

        addListeners();
    }

    private void addListeners() {
        for(int i=0; i<10; i++) {
            final int j = i;
            rques.get(i).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                    rate.set(j, (int) rating);
                    fadeStart(tvtrans.get(j), rating);
                }
            });
        }

        bsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sum = 0;
                for(int i : rate) { sum+=i; }
                Intent result=new Intent(getContext(),PeaceResultActivity.class);
                result.putExtra("moods",moodID);
                result.putExtra("score",sum);
                startActivity(result);
               // Toast.makeText(view.getContext(), "Sum is :"+sum, Toast.LENGTH_SHORT).show();
                //    Fragment fragment = ;
            }
        });
    }

    private void fadeStart(TextView tv, float rate) {
        if(rate == 1f) { tv.setTextColor(Color.parseColor("#ff0000")); tv.setText("LEAST"); }
        if(rate == 2f) { tv.setTextColor(Color.parseColor("#e50000")); tv.setText("LESS"); }
        if(rate == 3f) { tv.setTextColor(Color.parseColor("#990000")); tv.setText("OFTEN"); }
        if(rate == 4f) { tv.setTextColor(Color.parseColor("#4c0000")); tv.setText("MORE"); }
        if(rate == 5f) { tv.setTextColor(Color.parseColor("#190000")); tv.setText("MOST"); }

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeIn.setFillAfter(true);
        fadeOut.setFillAfter(true);
        fadeIn.setDuration(300);
        fadeOut.setDuration(300);
        fadeOut.setStartOffset(600+fadeIn.getStartOffset());

        tv.setVisibility(View.VISIBLE);
        tv.startAnimation(fadeIn);
        tv.startAnimation(fadeOut);
        tv.setVisibility(View.INVISIBLE);
    }
//FOOD
    private void init() {
        ques = new ArrayList<>();
        ques.add("➔ I find that when I start eating certain foods, I end up eating much more than planned?");
        ques.add("➔ I find myself continuing to consume certain foods even though I am no longer hungry ?");
        ques.add("➔ I eat to the point where I feel physically ill ?");
        ques.add("➔ Not eating certain types of food or cutting down on certain types of food is something I worry about ?");
        ques.add("➔ I spend a lot of time feeling sluggish or fatigued from overeating?");
        ques.add("➔ I find myself constantly eating certain foods throughout the day?");
        ques.add("➔ My food consumption has caused significant psychological problems such as depression, anxiety, self-loathing, or guilt?");
        ques.add("➔ Over time, I have found that I need to eat more and more to get the feeling I want, such as reduced negative emotions or increased pleasure?");
        ques.add("➔ My behavior with respect to food and eating causes significant distress. ?");
        ques.add("➔ I have tried to cut down or stop eating certain kinds of food?");


        List<TextView> ids = new ArrayList<>();
        List<RatingBar> rids = new ArrayList<>();
        List<TextView> tids = new ArrayList<>();

        ids.add((TextView) view.findViewById(R.id.ib3_tvques1));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques2));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques3));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques4));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques5));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques6));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques7));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques8));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques9));
        ids.add((TextView) view.findViewById(R.id.ib3_tvques10));


        rids.add((RatingBar) view.findViewById(R.id.ib3_rques1));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques2));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques3));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques4));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques5));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques6));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques7));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques8));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques9));
        rids.add((RatingBar) view.findViewById(R.id.ib3_rques10));


        tids.add((TextView) view.findViewById(R.id.ib3_trans1));
        tids.add((TextView) view.findViewById(R.id.ib3_trans2));
        tids.add((TextView) view.findViewById(R.id.ib3_trans3));
        tids.add((TextView) view.findViewById(R.id.ib3_trans4));
        tids.add((TextView) view.findViewById(R.id.ib3_trans5));
        tids.add((TextView) view.findViewById(R.id.ib3_trans6));
        tids.add((TextView) view.findViewById(R.id.ib3_trans7));
        tids.add((TextView) view.findViewById(R.id.ib3_trans8));
        tids.add((TextView) view.findViewById(R.id.ib3_trans9));
        tids.add((TextView) view.findViewById(R.id.ib3_trans10));


        bsubmit = (Button) view.findViewById(R.id.ib3_bsubmit);

        tvques = new ArrayList<TextView>();
        rques = new ArrayList<RatingBar>();
        tvtrans = new ArrayList<>();
        rate = new ArrayList<>();

        for(int i=0; i<10; i++) {
            tvques.add( ids.get(i) );
            rques.add( rids.get(i) );
            tvtrans.add( tids.get(i) );
            tvques.get(i).setText(ques.get(i));
            rate.add(0);
        }
    }

}
