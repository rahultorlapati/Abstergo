package com.capstone.rahul.exity10.activities;

import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

public class PeaceResultActivity extends AppCompatActivity {


    private static final String TAG = "Peace Result";
    private int res,score;
    private CircularProgressBar circularProgressBar;
    private TextView scoree,remarks,remedy;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peace_result);

        circularProgressBar = findViewById(R.id.circularresult);
        scoree=findViewById(R.id.score);
        remarks=findViewById(R.id.remarks);
        remedy=findViewById(R.id.remedyy);

        getIncomingIntent();
        showprogress();
    }

    private void getIncomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
        if (getIntent().hasExtra("moods") && getIntent().hasExtra("score")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");
            res=extras.getInt("moods");
            score=extras.getInt("score");
        }
    }

    public void showprogress(){
        int animationDuration = 2500; // 2500ms = 2,5s
        int progress=(score*100)/50;
        circularProgressBar.setProgressWithAnimation(progress, animationDuration);
        scoree.setText(Integer.toString(score));

        if(score>0 && score<=10){
            remarks.setText("Very Low");
        }else if(score>10 &&score<=20){
            remarks.setText("Low");
        }else if(score>20 && score<=30){
            remarks.setText("Mediocre");
        }else if(score>30 && score<=40){
            remarks.setText("High");
        }else if(score>40 && score<=50){
            remarks.setText("Very High");
        }

        switch(res){
            case(1):
                remedy.setText(getString(R.string.stress));
                break;
            case(2):
                remedy.setText(getString(R.string.lifesatisfy));
                break;
            case(3):
                remedy.setText(getString(R.string.food));
                break;
            case(4):
                remedy.setText(getString(R.string.happiness));
                break;
            case(5):
                remedy.setText(getString(R.string.Anger));
                break;
            case(6):
                remedy.setText(getString(R.string.anxiety));
                break;
            case(7):
                remedy.setText(getString(R.string.depression));
                break;
            case(8):
                remedy.setText(getString(R.string.emotional));
                break;
            default:
        }
    }
}
