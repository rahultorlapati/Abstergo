package com.capstone.rahul.exity10.fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;

import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.activities.MainActivity;
import com.capstone.rahul.exity10.sql.Session;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;


public class JournalFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    View v;

    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public JournalFragment() {

    }

    public static JournalFragment newInstance(String param1, String param2) {
        JournalFragment fragment = new JournalFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    private ArrayList<String> fieldds;
    private static final String API_URL = "https://api.nutritionix.com/v1_1/search";
    TextView calView,carbView,FatView,ProtView;
    private Session session;
    public CircularProgressBar circularProgressBar;
    public int animationDuration = 2500;
    public int staticcal = 3070;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v=inflater.inflate(R.layout.fragment_journal, container, false);
        final EditText popUpBox = new EditText(getContext());

        session=new Session(getContext());

        FatView = (TextView) v.findViewById(R.id.FatsEditView);
        carbView = (TextView) v.findViewById(R.id.CarbsEditView);
        calView = (TextView) v.findViewById(R.id.caloriesval);
        ProtView = (TextView) v.findViewById(R.id.ProteinEditView);

        fieldds=new ArrayList<>();
        fieldds.add("nf_calories");
        fieldds.add("nf_total_fat");
        fieldds.add("nf_protein");
        fieldds.add("nf_total_carbohydrate");

        TextView showdialog=v.findViewById(R.id.addbreakfast);
        showdialog.setText(session.getbreakfast("Breakfast"));
        showdialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {popUpRequest(v);}});

        TextView showdialog1=v.findViewById(R.id.addlunch);
        showdialog1.setText(session.getlunch("Lunch"));
        showdialog1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {popUpRequest(v);}});


        TextView showdialog2=v.findViewById(R.id.adddinner);
        showdialog2.setText(session.getdinner("Dinner"));
        showdialog2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {popUpRequest(v);}});


        TextView showdialog3=v.findViewById(R.id.addsnacks);
        showdialog3.setText(session.getsnacks("Snacks"));
        showdialog3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {popUpRequest(v);}});

        calView.setText(Float.toString(session.getfoodval("holdcalorie")));
        ProtView.setText(Float.toString(session.getfoodval("holdprotein")));
        carbView.setText(Float.toString(session.getfoodval("holdcarbs")));
        FatView.setText(Float.toString(session.getfoodval("holdfats")));


        circularProgressBar = (CircularProgressBar) v.findViewById(R.id.circularprogressbar);
        float progress = (session.getfoodval("holdcalorie") / staticcal) * 100;
        circularProgressBar.setProgressWithAnimation(progress, animationDuration);

        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    
    @SuppressLint("ResourceAsColor")
    public void popUpRequest(final View view) {
        final AlertDialog.Builder popUp = new AlertDialog.Builder(getActivity());
        switch (view.getId())
        {
            case R.id.addbreakfast:
                popUp.setTitle("Breakfast");
                break;

            case R.id.addlunch:
                popUp.setTitle("Lunch");
                break;

            case R.id.adddinner:
                popUp.setTitle("Dinner");
                break;

            case R.id.addsnacks:
                popUp.setTitle("Snacks");
                break;
        }

        final EditText popUpBox = new EditText(getActivity());
        popUpBox.setBackgroundTintList(ColorStateList.valueOf(R.color.colorAccent));
        popUp.setView(popUpBox);

        AlertDialog.Builder builder = popUp.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String input = popUpBox.getText().toString();
                switch (view.getId()) {
                    case R.id.addbreakfast:
                        final TextView breakfast = view.findViewById(R.id.addbreakfast);
                        breakfast.setText(String.valueOf(input));
                        session.setbreakfast("Breakfast",input);
                        break;

                    case R.id.addlunch:
                        final TextView lunch = view.findViewById(R.id.addlunch);
                        lunch.setText(String.valueOf(input));
                        session.setlunch("Lunch",input);
                        break;

                    case R.id.adddinner:
                        final TextView dinner = view.findViewById(R.id.adddinner);
                        dinner.setText(String.valueOf(input));
                        session.setdinner("Dinner",input);
                        break;

                    case R.id.addsnacks:
                        final TextView snacks = view.findViewById(R.id.addsnacks);
                        snacks.setText(String.valueOf(input));
                        session.setsnacks("Snacks",input);
                        break;
                }
                RequestQueue requestQueue = Volley.newRequestQueue(getContext());
                try {
                    JSONObject postparams = new JSONObject();
                    JSONArray jsArray = new JSONArray(fieldds);
                    postparams.put("query", input);
                    postparams.put("fields", jsArray);
                    postparams.put("appId", getString(R.string.appid));
                    postparams.put("appKey", getString(R.string.appkey));

                    JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                            API_URL, postparams,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    Log.i("VOLLEY", "Response");

                                    Log.d("JSONOBJECT RECEIVED", "onResponse: " + response);
                                    try {

                                        JSONObject obj = response;
                                        JSONArray hitsarr = obj.getJSONArray("hits");
                                        JSONObject c = hitsarr.getJSONObject(0);
                                        JSONObject fields = c.getJSONObject("fields");

                                        String cal = fields.getString("nf_calories");
                                        String fat = fields.getString("nf_total_fat");
                                        String protein = fields.getString("nf_protein");
                                        String carbs = fields.getString("nf_total_carbohydrate");

                                        float holdcal=Float.parseFloat(cal);
                                        holdcal=(int)holdcal;
                                        holdcal+=session.getfoodval("holdcalorie");
                                        session.setfoodval("holdcalorie",holdcal);

                                        float holdprotein=Float.parseFloat(protein);
                                        holdprotein=(int)holdprotein;
                                        holdprotein+=session.getfoodval("holdprotein");
                                        session.setfoodval("holdprotein",holdprotein);

                                        float holdfats=Float.parseFloat(fat);
                                        holdfats=(int)holdfats;
                                        holdfats+=session.getfoodval("holdfats");
                                        session.setfoodval("holdfats",holdfats);

                                        float holdcarbs=Float.parseFloat(carbs);
                                        holdcarbs=(int)holdcarbs;
                                        holdcarbs+=session.getfoodval("holdcarbs");
                                        session.setfoodval("holdcarbs",holdcarbs);


                                        calView.setText(Float.toString(session.getfoodval("holdcalorie")));
                                        ProtView.setText(Float.toString(session.getfoodval("holdprotein")));
                                        carbView.setText(Float.toString(session.getfoodval("holdcarbs")));
                                        FatView.setText(Float.toString(session.getfoodval("holdfats")));


                                        float progress = (holdcal / staticcal) * 100;
                                        circularProgressBar.setProgressWithAnimation(progress, animationDuration);


                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                        }
                    }) {

                        @Override
                        public Map<String, String> getHeaders() throws AuthFailureError {
                            Map<String, String> headers = new HashMap<String, String>();
                            headers.put("Content-Type", "application/json");

                            Log.i("In getHeaders", headers.toString());
                            return headers;
                        }

                    };

                    requestQueue.add(jsonObjReq);
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }

            }
        });
        popUp.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        popUp.show();

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            //Toast.makeText(context, "Fragment Attached", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
