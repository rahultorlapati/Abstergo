package com.capstone.rahul.exity10.activities;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.capstone.rahul.exity10.R;

public class ExcersiseShowActivity extends AppCompatActivity {

    private static final String TAG = "ExcersiseShowActivity";
    private ImageView imageView;
    private TextView EngAsana;
    private TextView SanskritAsana;
    private TextView Description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excersise_show);

        EngAsana=findViewById(R.id.englishAsana);
        SanskritAsana=findViewById(R.id.SanskritAsana);
        Description=findViewById(R.id.asanadescription);

        EngAsana.setText(getString(R.string.asana1));
        SanskritAsana.setText(getString(R.string.asana1sansk));
        Description.setText(getString(R.string.asanadescription));
        imageView= findViewById(R.id.imageView2);
        getIcomingIntent();
    }
    private void getIcomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
        if (getIntent().hasExtra("img name")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");

            int res = extras.getInt("img name");
            setImage(res);

        }
    }

    private void setImage(int res) {


        imageView.setImageResource(res);
    }
}
