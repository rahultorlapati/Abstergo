package com.capstone.rahul.exity10.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.capstone.rahul.exity10.R;

public class PeaceResultActivity extends AppCompatActivity {


    private static final String TAG = "Peace Result";
    private int res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peace_result);

        getIncomingIntent();
    }

    private void getIncomingIntent() {

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.d(TAG, "getIcomingIntent: Bundle Extra error");
            return;
        }
        if (getIntent().hasExtra("diet url") && getIntent().hasExtra("diet name")) {
            Log.d(TAG, "getIcomingIntent: Found Extras");
            res=extras.getInt("moods");
        }
    }
}
