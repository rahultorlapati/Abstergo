package com.capstone.rahul.exity10.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.capstone.rahul.exity10.R;
import com.capstone.rahul.exity10.model.User;
import com.capstone.rahul.exity10.sql.DatabaseHelper;
import com.capstone.rahul.exity10.sql.Session;

import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {

    private final AppCompatActivity activity=ProfileActivity.this;

    private User getUser;
    private DatabaseHelper databaseHelper;
    private Session session;
    private TextView userName,userEmail,userHeight,userWeight,userAge,userGender;
    private  String currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        init();

        getDataFromSQLite();

        //userName.setText(getUser.getName());
        //userEmail.setText(getUser.getEmail());
    }

    public void init(){
        session=new Session(this);
        databaseHelper = new DatabaseHelper(activity);
        getUser=new User();

        userName=findViewById(R.id.editName);
        userEmail=findViewById(R.id.email);
        userHeight=findViewById(R.id.user_height);
        userWeight=findViewById(R.id.user_weight);
        userAge=findViewById(R.id.editAge);
        userGender=findViewById(R.id.user_gender);

        currentUser=session.getemail("email");
    }

    private void getDataFromSQLite() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                //getUser.clear();
                if(currentUser!=null){
                if(databaseHelper.checkUser(currentUser)) {
                    getUser = databaseHelper.getUserData(currentUser);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            // runs on UI thread
                            //Toast.makeText(getApplicationContext(), "User email " + currentUser + "\nUser name " + getUser.getName(), Toast.LENGTH_LONG).show();

                        }
                    });
                   }
                else {
                         Log.d("In ASYNC Background", "details not fetched ");
                        Toast.makeText(getApplicationContext(),"User not verified",Toast.LENGTH_LONG).show();
                    }
                }else{
                    Log.d("doInBackground", "EROROROROROROR...shared preference not working  ");
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                userName.setText(getUser.getName());
                userEmail.setText(getUser.getEmail());
                userHeight.setText(getString(R.string.user_set_Height,getUser.getHeight()));
                userWeight.setText(getString(R.string.user_set_Weight,getUser.getWeight()));
                userAge.setText(getString(R.string.user_set_Age,getUser.getAge()));
                userGender.setText(getUser.getGender());
               // usersRecyclerAdapter.notifyDataSetChanged();
            }
        }.execute();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.editmenu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return true;
    }

    public void ActLogout(View view) {
        logout();
    }
    private void logout(){
        session.setLoggedin(false);
        finish();
        startActivity(new Intent(ProfileActivity.this,loginActivity.class));
    }
}
