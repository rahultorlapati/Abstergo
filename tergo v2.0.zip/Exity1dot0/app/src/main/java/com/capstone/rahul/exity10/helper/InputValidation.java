package com.capstone.rahul.exity10.helper;

import android.app.Activity;
import android.content.Context;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethod;
import android.view.inputmethod.InputMethodManager;

/**
 * Created by Sagar on 08-04-2018.
 */

public class InputValidation {
    private Context context;

    public InputValidation(Context context) {
        this.context = context;
    }
    //If the editText is Empty
    public boolean isinputEditTextFilled(TextInputEditText textInputEditText, TextInputLayout textInputLayout, String message) {
        String value = textInputEditText.getText().toString().trim();
        if (value.isEmpty()) {
            textInputLayout.setError(message);
            hideKeyboardFrom(textInputEditText);
            return false;
        }else{
            textInputLayout.setErrorEnabled(false);
        }
        return true;
    }
    //Wrong type of email
    public boolean isInputEditTextEmail(TextInputEditText textInputEditText,TextInputLayout textInputLayout,String messsge){
        String value=textInputEditText.getText().toString().trim();
        if(value.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(value).matches()){
            textInputLayout.setError(messsge);
            hideKeyboardFrom(textInputEditText);
            return false;
        }else{
         textInputLayout.setErrorEnabled(false);
        }
        return true;
    }
    //Fields have same value
    public boolean isInputEditTextMatches(TextInputEditText textInputEditText,TextInputEditText textInputEditText2,TextInputLayout textInputLayout,String message){
        String value1=textInputEditText.getText().toString().trim();
        String value2=textInputEditText2.getText().toString().trim();

        if(!value1.contentEquals(value2)){
            textInputLayout.setError(message);
            hideKeyboardFrom(textInputEditText2);
            return false;
        }else{
            textInputLayout.setErrorEnabled(false);
        }
        return true;
    }
    //to hide keyboard when error is encountered
    private void hideKeyboardFrom(View view){
        InputMethodManager imm=(InputMethodManager)context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
}

